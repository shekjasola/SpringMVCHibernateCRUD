package com.iiht.exception;

import com.iiht.exception.InvalidMapSkillException;

public class InvalidMapSkillException extends RuntimeException {
	public InvalidMapSkillException() {
		super("No such mapskill exists");
	}

}
