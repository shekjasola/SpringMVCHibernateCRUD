package com.iiht.dao;

import java.util.List;

import com.iiht.model.Skill;

public interface SkillDAO {

	public void addSkill(Skill skill);

	public List<Skill> getAllSkill();

	public void deleteSkill(Integer skillId);

	public Skill updateSkill(Skill skill);

	public Skill getSkill(int skillid);
}
