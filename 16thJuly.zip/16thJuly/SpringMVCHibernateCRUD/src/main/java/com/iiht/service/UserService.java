package com.iiht.service;

import java.util.List;
import java.util.Map;


import com.iiht.model.User;
import com.iiht.model.Skill;

public interface UserService {

	public void addUser(User user);

	public List<User> getUser();

	public void deleteUser(Long userID);

	public User editUser(User user);

}
