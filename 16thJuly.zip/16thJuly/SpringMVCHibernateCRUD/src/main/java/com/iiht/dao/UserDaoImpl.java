package com.iiht.dao;

import java.util.List;
import java.util.Map;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import com.iiht.dao.UserDaoImpl;

import com.iiht.model.User;
import com.iiht.model.Skill;
import com.iiht.dao.UserDaoImpl;
import com.iiht.dao.UserDaoImpl;

@Repository("userDao")
@Transactional(propagation= Propagation.REQUIRED)
public class UserDaoImpl implements UserDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addUser(User user) {
		sessionFactory.getCurrentSession().saveOrUpdate(user);
	}
	
	@SuppressWarnings("unchecked")
	public List<User> getUser() {

		return sessionFactory.getCurrentSession().createQuery("from User").list();
	}

	
	@Override
	public void deleteUser(Long userId) {
		User user = (User) sessionFactory.getCurrentSession().load(Skill.class, userId);
		if (null != user) {
			this.sessionFactory.getCurrentSession().delete(user);
		}
		
	}

		@Override
		public User editUser(User user) {
			sessionFactory.getCurrentSession().update(user);
			return user;
		}


}
