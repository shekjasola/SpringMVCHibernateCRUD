package com.iiht.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.iiht.model.Skill;
import com.iiht.service.SkillService;

@Controller
public class SkillController {

	private static final Logger logger = Logger.getLogger(SkillController.class);

	public SkillController() {
		System.out.println("SkillController()");
	}

	@Autowired
	private SkillService skillService;

	@RequestMapping(value = "/")
	public ModelAndView listEmployee(ModelAndView model) throws IOException {
		List<Skill> listskill = skillService.getAllSkill();
		model.addObject("listskill", listskill);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newSkill", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Skill skill = new Skill();
		model.addObject("Skill", skill);
		model.setViewName("SkillForm");
		return model;
	}

	@RequestMapping(value = "/saveSkill", method = RequestMethod.POST)
	public ModelAndView saveEmployee(@ModelAttribute Skill skill) {
		if (skill.getSkill_id() == 0) { // if employee id is 0 then creating the
			// employee other updating the employee
			skillService.addSkill(skill);
		} else {
			skillService.updateSkill(skill);
		}
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/deleteSkill", method = RequestMethod.GET)
	public ModelAndView deleteTask(HttpServletRequest request) {
		int skill = Integer.parseInt(request.getParameter("skill_id"));
		skillService.deleteSkill(skill);
		return new ModelAndView("redirect:/");
	}

	@RequestMapping(value = "/editSkill", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int skillId = Integer.parseInt(request.getParameter("skill_id"));
		Skill skill = skillService.getSkill(skillId);
				
		ModelAndView model = new ModelAndView("SkillForm");
		model.addObject("skill",skill);

		return model;
	}

}