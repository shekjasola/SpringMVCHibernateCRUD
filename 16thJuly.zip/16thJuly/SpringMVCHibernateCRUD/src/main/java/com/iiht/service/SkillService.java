package com.iiht.service;

import java.util.List;

import com.iiht.model.Skill;

public interface SkillService {
	
	public void addSkill(Skill skill);

	public List<Skill> getAllSkill();

	public void deleteSkill(Integer skillId);

	public Skill getSkill(int skillid);

	public Skill updateSkill(Skill skill);
}
