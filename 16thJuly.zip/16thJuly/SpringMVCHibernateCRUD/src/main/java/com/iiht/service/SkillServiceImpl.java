package com.iiht.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.iiht.dao.SkillDAO;
import com.iiht.model.Skill;

@Service
@Transactional
public class SkillServiceImpl implements SkillService {

	@Autowired
	private SkillDAO skillDAO;

	@Override
	@Transactional
	public void addSkill(Skill skill) {
		skillDAO.addSkill(skill);
	}

	@Override
	@Transactional
	public List<Skill> getAllSkill() {
		return skillDAO.getAllSkill();
	}

	@Override
	@Transactional
	public void deleteSkill(Integer skillId) {
		skillDAO.deleteSkill(skillId);
	}

	public Skill getSkill(int skillId) {
		return skillDAO.getSkill(skillId);
	}

	public Skill updateSkill(Skill skill) {
		// TODO Auto-generated method stub
		return skillDAO.updateSkill(skill);
	}

	public void setTaskDAO(SkillDAO skillDAO) {
		this.skillDAO = skillDAO;
	}

}
