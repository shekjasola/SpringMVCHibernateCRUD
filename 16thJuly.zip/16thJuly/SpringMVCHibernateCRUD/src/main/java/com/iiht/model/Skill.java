package com.iiht.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import lombok.Data;

@Entity
@Data
@Table(name = "Skill_TBL")
public class Skill implements Serializable {

	private static final long serialVersionUID = -3465813074586302847L;

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int skill_id;

	@Column
	private String task_name;

	@Column
	private String task_satus;

	@Column
	private String task_start_date;

	@Column
	private String task_end_date;

	
	@Column
	private String task_color_code;

	@ManyToOne
	@JoinColumn(name="UserId", nullable=false)
    private User user;
	
	public int getSkill_id() {
		return skill_id;
	}


	public void setskill_id(int task_id) {
		this.skill_id = task_id;
	}


	public String getTask_name() {
		return task_name;
	}


	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}


	public String getTask_satus() {
		return task_satus;
	}


	public void setTask_satus(String task_satus) {
		this.task_satus = task_satus;
	}


	public String getTask_start_date() {
		return task_start_date;
	}


	public void setTask_start_date(String task_start_date) {
		this.task_start_date = task_start_date;
	}


	public String getTask_end_date() {
		return task_end_date;
	}


	public void setTask_end_date(String task_end_date) {
		this.task_end_date = task_end_date;
	}


	public String getTask_color_code() {
		return task_color_code;
	}


	public void setTask_color_code(String task_color_code) {
		this.task_color_code = task_color_code;
	}


	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	

	
}