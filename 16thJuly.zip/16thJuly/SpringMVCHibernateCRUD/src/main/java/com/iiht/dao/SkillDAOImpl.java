package com.iiht.dao;

import java.util.List;

import org.hibernate.SessionFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.iiht.model.Skill;

@Repository
public class SkillDAOImpl implements SkillDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public void addSkill(Skill skill) {
		sessionFactory.getCurrentSession().saveOrUpdate(skill);

	}

	@SuppressWarnings("unchecked")
	public List<Skill> getAllSkill() {

		return sessionFactory.getCurrentSession().createQuery("from Skill").list();
	}

	@Override
	public void deleteSkill(Integer skillId) {
		Skill skill = (Skill) sessionFactory.getCurrentSession().load(Skill.class, skillId);
		if (null != skill) {
			this.sessionFactory.getCurrentSession().delete(skill);
		}

	}

	public Skill getSkill(int skillid) {
		return (Skill) sessionFactory.getCurrentSession().get(Skill.class, skillid);
	}

	@Override
	public Skill updateSkill(Skill skill) {
		sessionFactory.getCurrentSession().update(skill);
		return skill;
	}

}