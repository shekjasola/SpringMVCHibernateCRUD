package com.iiht.boundarycases;



import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import com.iiht.testutils.JsonUtils;

import org.springframework.context.annotation.Bean;

import com.iiht.model.User;
import org.springframework.test.context.junit.jupiter.SpringExtension;


@ExtendWith(SpringExtension.class)
public class BoundaryTests {
	
	@Test
	public void testFirstNameLength() throws Exception {

		User user = JsonUtils.createUser(1, "Shekhar", "Prasad", "shekjava@gmail.com", "Java");
		int maxChar = 7;
		boolean fname = ((user.getFirstName().length()) >= maxChar);
		 yakshaAssert(currentTest(),(fname?true:false),boundaryTestFile);

	}
	
	@Test
	public void testLastNameLength() throws Exception {
		User user = JsonUtils.createUser(1, "Shekhar", "Prasad", "shekjava@gmail.com", "Java");
		int maxChar = 6;
		boolean lname = ((user.getLastName().length()) >= maxChar);
		 yakshaAssert(currentTest(),(lname?true:false),boundaryTestFile);

	}
  }
