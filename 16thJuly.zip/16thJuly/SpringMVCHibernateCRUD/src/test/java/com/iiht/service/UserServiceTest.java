package com.iiht.service;



import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import com.iiht.testutils.JsonUtils;


import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import com.iiht.testutils.TestUtils;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.iiht.service.UserService;
import com.iiht.model.User;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
import com.iiht.service.UserServiceTest;
@ExtendWith(SpringExtension.class)
public class UserServiceTest {
	
	@TestConfiguration
    static class UserServiceImplTestContextConfiguration {
        @Bean
        public UserService noteService() {
            return new UserServiceImpl();
        }
    }
	
	@Autowired
    private UserService userService;

    @MockBean
    private CrudRepository crudRepository;

    
    @BeforeEach
    public void setUp() {
        User user1 = JsonUtils.createUser((long) 1, "Shekhar", "Prasad", "shekjava@gmail.com", "Java");
        User user2 = JsonUtils.createUser((long) 2, "Ajay", "Kumar", "ajaukumar@gmail.com", "Spring MVC");
        User user3 = JsonUtils.createUser((long) 3, "Vijay", "Kumar", "vijaykumar@gmail.com", "Spring MVC");
     
        List<User> user4 = Arrays.asList(user1,user2,user3);
        List<User> user5 = Arrays.asList(user2,user3);

        Mockito.when(userService.getUser(user1)).thenReturn(user1);
        Mockito.when(userService.addUser("Ajay")).thenReturn(user5);
        Mockito.when(userService.deleteUser("Vijay").thenReturn(Optional.of(user3));
        Mockito.when(userService.editUser("Shekhar")).thenReturn(user1);
        
     }
    
	@Test
	void testGetUser() throws IOException {
		List<User> fromDb = userService.getUser();
		assertEquals(fromDb.size(),3);
		int count= fromDb.size();
		yakshaAssert(currentTest(),(count==3?true:false),businessTestFile);
	}

	@Test
	void testaddUser() throws IOException {
		User user = JsonUtils.createUser((long) 1, "Shekhar", "Prasad", "shekjava@gmail.com", "Java");
		Mockito.when(userService.addUser(user)).thenReturn(user);
		User user1 = userService.addUser(user);
		yakshaAssert(currentTest(),(user1!=null?true:false),businessTestFile);
	}
	
	@Test
	void testeditUser() throws IOException {
		
		User user = JsonUtils.createUser((long) 1, "Akash", "Kumar", "shekjava@gmail.com", "Java");
		Mockito.when(userService.editUser(user).thenReturn(user);
		User user1 = userService.editUser(user);
		yakshaAssert(currentTest(),(user1.getUserId().equals(user.getUserId())?true:false),businessTestFile);
	}

	@Test
	void testgetUser() throws IOException {
		 User user1 = JsonUtils.createUser((long) 1, "Shekhar", "Prasad", "shekjava@gmail.com", "Java");
		 User user3 = JsonUtils.createUser((long) 2, "Ajay", "Kumar", "ajaykumar@gmail.com", "Spring MVC");
		 List<User> user4 = Arrays.asList(user1,user3);
		 Mockito.when(userService.getUser("Shekhar").thenReturn(user4);
	     List<User> list1 = userService.getUser("Shekhar");
	  
	     yakshaAssert(currentTest(),(user4.containsAll(list1)?true:false),businessTestFile);
	}
}

