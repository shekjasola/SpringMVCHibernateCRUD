package com.iiht.exceptioncases;

import static org.assertj.core.api.Assertions.assertThat;
import com.iiht.service.UserService;
import static org.junit.jupiter.api.Assertions.*;
import com.iiht.service.UserServiceImpl;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import org.assertj.core.api.Assert;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import org.springframework.context.annotation.Bean;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.context.TestConfiguration;
import com.iiht.testutils.JsonUtils;

import com.iiht.testutils.JsonUtils;
import com.iiht.service.UserService;
import com.iiht.model.User;
import com.iiht.exception.InvalidMapSkillException;
import  org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;
@ExtendWith(SpringExtension.class)

public class ExceptionTest {
	
	@TestConfiguration
    static class UserServiceImplTestContextConfiguration {
        @Bean
        public UserService userService() {
            return new UserServiceImpl();
        }
    }

	@Autowired
    private UserService userService;

    @MockBean
    private CrudRepository crudRepository;

	@Test
	public void testInvalidMapSkill() throws IOException {
		Mockito.when(userService.getMapSkill("Java"))
        .thenThrow(InvalidMapSkillException.class);
		
		InvalidMapSkillException e = assertThrows(InvalidMapSkillException.class, () -> {
		    userService.getMapSkill("Java");
		  });
		yakshaAssert(currentTest(),(e!=null?true:false),exceptionTestFile);	       	
	}
	
	@Test
	public void testInvalidUserId() throws IOException {
		 User user1 = JsonUtils.createUser( 1, "Shekhar", "Prasad", "shekjava@gmail.com", "java");
		
		 Mockito.when(userService.getUserId((Long) 1)).thenThrow(InvalidUserIdException.class);
		
		 InvalidUserIdException e = assertThrows(InvalidUserIdException.class, () -> {
		    userService.getUserId((Long)1);
		  });
	 yakshaAssert(currentTest(),(e!=null?true:false),exceptionTestFile);
	}
  }
